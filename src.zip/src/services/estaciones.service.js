"use strict";

const mongo = require('mongoose');

const EstacionModel = require('../models/estacion.model');
const AppError = require('../utils/appError');

class EstacionService {
    async getAll() {
        
    }
}
"use strict";

class AppError extends Error {
    constructor(statusCode, message, details = null) {
        super(message);
        this.name = 'AppError';
        this.statusCode = statusCode;
        this.datails = details;
        this.isOperational = true;

        Error.captureStackTrace(this, this.constructor);
    }
}

module.exports = AppError;